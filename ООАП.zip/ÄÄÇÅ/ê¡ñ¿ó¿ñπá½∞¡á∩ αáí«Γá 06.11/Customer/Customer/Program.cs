﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Customer
{
    public class Customer
    {
        public string name;
        public int phoneNumber;
        public string Email;

        public Customer(string name, int phoneNumber, string Email)
        {
            this.name = name;
            this.phoneNumber = phoneNumber;
            this.Email = Email;
        }

        public Goods ViewGoods(Goods good)
        {
            Console.WriteLine("Просмотр товаров...");  //тут можно добавить условие проверки (если по пареметрам истраивает, то товар возвращается)
            return good;
        }
    }

    public class Order
    {
        public bool status = false;
        public int cost;

        public Order(Goods ListOfGoods)
        {
            for(int i = 0; i < ListOfGoods.Lenght; i++)
            {
                if (ListOfGoods[i] != null)
                {
                    cost += ListOfGoods.price;
                }
            }
        }

        public bool MakePayment(string status, Order order)
        {
            Console.WriteLine("Производится полата...");
            while (order.status == false)
            {
                return false;
            }
            return true;
        }

    }

    public class Goods
    {
        public string name;
        public int price;

        public Goods(string name, int price)
        {
            this.name = name;
            this.price = price;
        }
    }

    public class Busket
    {
        public Goods[] ListOfGoods = new Goods[100];

        public void AddGood(Goods good)
        {
            for(int i = 0; i <= ListOfGoods.Length; i++)
            {
                if (ListOfGoods[i] != null)
                {
                    ListOfGoods[i] = good;
                }
            }
        }

        public void MakeOrder(Goods ListOfGoods)
        {
            Order order = new Order(ListOfGoods);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Customer human = new Customer("John", 8913859, "JohnDoe@visual.com");
            Goods good = new Goods("Dress", 1500);
            Busket bag = new Busket();

            human.ViewGoods(good);
            bag.AddGood(good);
            //bag.MakeOrder(ListOfGoods)
        }
    }
}
