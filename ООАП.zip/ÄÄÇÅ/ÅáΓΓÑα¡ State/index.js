let btnSave = document.getElementById('save');
let display = document.querySelector('#editor'); 
let setText = document.getElementById('text');

display.addEventListener('change', () =>{ });

function save() {
  setText.innerHTML = `<div style="font-weight: bold;">Создана новая заметка!</div>` + display.value;
}
  
let count = 0;

// const textState = {
//     'default': {
//       handleStateChange:function() {
//         display.removeAttribute('style')
//         display.setAttribute('style', 'text-decoration: none;')
//         this.button.innerHTML = 'Нормальный'
//         this.setState(textState.bold)
//       }
//     },
//     'bold': {
//       handleStateChange:function() {
//         display.setAttribute('style', 'font-weight: bold;')  
//         this.button.innerHTML = 'Жирный'
//         this.setState(textState.italic)
//       }
//     },
//     'italic': {
//       handleStateChange:function() {
//         display.removeAttribute('style')
//         display.setAttribute('style', 'font-style: italic;')
//         this.button.innerHTML = 'Курсив'
//         this.setState(textState.default)
//       }
//     }
//   }
  
//   class Transform {
//     constructor () {
//       this.currentState = textState.bold
//       this.button = null
//     }
  
//     init () {
//       if(count == 0) {
//         const button = document.createElement('button')
//         count++;
//         this.button = btnSave.insertAdjacentElement('beforeBegin', button)
//         this.button.innerHTML = 'Нормальный'
//         this.button.setAttribute('style', 'margin: 40px 20px 0px 20px; font-family: "Courier"; font-size: 18px; padding: 5px; border: 1px solid rgb(178, 185, 187); background-color: lightgray; cursor: pointer;')
//         this.button.onclick = () => {
//             this.currentState.handleStateChange.call(this) 
//         }
//       }
//     }
  
//     setState (newState) {
//       this.currentState = newState
//     }
//   }
    
//   let editor = new Transform();

class TextEditor {
  constructor() {
      this.states = [new BoldState(), new ItalicState(), new DefaultState()];
      this.current = this.states[0];
      this.button = null
  }

  init () {
    if(count == 0) {
      const button = document.createElement('button')
      count++;
      console.log('Button was created');   //
      this.button = btnSave.insertAdjacentElement('beforeBegin', button)
      this.button.innerHTML = 'Нормальный'
      this.button.setAttribute('style', 'margin: 40px 20px 0px 20px; font-family: "Courier"; font-size: 18px; padding: 5px; border: 1px solid rgb(178, 185, 187); background-color: lightgray; cursor: pointer;')
      this.button.onclick = () => {
        this.current.handleStateChange.call(this) 
      }
    }
  }

  setState() {
      const totalStates = this.states.length;
      let currentIndex = this.states.findIndex(transform => transform === this.current);
      if (currentIndex + 1 < totalStates) this.current = this.states[currentIndex + 1];
      else this.current = this.states[0];
  }
}

class Transformation {
    constructor(transform) {
        this.transform = transform;
    }
} 

class BoldState extends Transformation {
  constructor() {
      super('bold');
  }

  handleStateChange() {
    console.log('Bold');   //
    display.setAttribute('style', 'font-weight: bold;')  
    this.button.innerHTML = 'Жирный'
    this.setState()
  }
}

class ItalicState extends Transformation {
  constructor() {
      super('italic');
  }

  handleStateChange() {
    console.log('Italic');   //
    display.removeAttribute('style')
    display.setAttribute('style', 'font-style: italic;')
    this.button.innerHTML = 'Курсив'
    this.setState()
  }
}

class DefaultState extends Transformation {
    constructor() {
        super('default');
    }

    handleStateChange() {
      console.log('Default');   //
      display.removeAttribute('style')
      display.setAttribute('style', 'text-decoration: none;')
      this.button.innerHTML = 'Нормальный'
      this.setState()
    }
}

let editor = new TextEditor();